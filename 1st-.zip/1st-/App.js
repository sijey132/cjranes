import React, { Component } from 'react';
import { View, Image, Text, ScrollView, StyleSheet } from 'react-native';

// Code example by Dr. Fuentes; May 21, 2023

export default class App extends Component {
  render() {
    return (
      <ScrollView>
        <View style={styles.container}>
          <Image
            source={{ uri: 'https://scontent.fmnl30-3.fna.fbcdn.net/v/t39.30808-6/448164821_1140103017268294_7159101107922404556_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=6ee11a&_nc_eui2=AeGYGvhbOgTV_GI5obhR9OI654UKY0xUoc7nhQpjTFShznI1tOF56B_h94if4Cxzq9a5D3uiRMRM9FF3J0CQqIpq&_nc_ohc=rlPJq1aFUBUQ7kNvgFSWufx&_nc_ht=scontent.fmnl30-3.fna&oh=00_AYDgJN-sMn4HGV_ijvNBbXx5a3y58U2uLALi0CsPwz8goQ&oe=66D44057' }}
            style={{ width: 200, height: 200 }}
          />
          <Text style={styles.text}>Christian Jay</Text>
          <Text style={styles.text}>24</Text>
          <Text style={styles.text}>3rd year</Text>
        </View>
        <View style={styles.container}>
          <Image
            source={{ uri: 'https://yourimageurl.com/your-image.jpg' }} // Replace with your own image URL
            style={{ width: 200, height: 200 }}
          />
          <Text style={styles.text}>BSIT Phinma UCL</Text>
        </View>
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 20,
  },
  text: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 10,
  },
});